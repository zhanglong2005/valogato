package org.vhorvath.valogato.common.dao.lowlevel.cache.impl;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vhorvath.valogato.common.cache.OneJvmCacheImpl;
import org.vhorvath.valogato.common.constants.ThrConstants;
import org.vhorvath.valogato.common.dao.lowlevel.cache.ICache;
import org.vhorvath.valogato.common.exception.ThrottlingConfigurationException;


/**
 * @author Viktor Horvath
 */
public class LocalCache implements ICache {

	
	private static final Logger LOGGER = LoggerFactory.getLogger(ThrConstants.THROTTLING_NAME);

	
	public void lock(String key) throws ThrottlingConfigurationException {
		LOGGER.trace(String.format("####### LocalCache.lock(%s)...", key));
		getOneJvmCacheImplInstance().lock(key);
		LOGGER.trace(String.format("####### Getting the LocalCache.lock(%s) was successful!", key));
	}

	
	public void unlock(String key) throws ThrottlingConfigurationException {
		LOGGER.trace(String.format("####### LocalCache.unlock(%s)", key));
		
		try {
			getOneJvmCacheImplInstance().unlock(key);
		} catch(Exception e) {
			LOGGER.warn(String.format("####### The LocalCache lock cannot be released! key = %s, reason = %s", key, ""+e));
		}
	}

	
	public <T> T get(String key, Class<T> type) throws ThrottlingConfigurationException {
		T value = null;
		try {
			value = getOneJvmCacheImplInstance().get(key, type);
			return value;
		} finally {
			LOGGER.trace(String.format("####### LocalCache.get(%s, %s) = %s", key, type, value));
		}
	}

	
	public void put(String key, Object value) throws ThrottlingConfigurationException {
		LOGGER.trace(String.format("####### LocalCache.put(%s, %s)", key, value));
		// put into the cache
		getOneJvmCacheImplInstance().put(key, value);
	}
	
	
	public List<String> getKeys() throws ThrottlingConfigurationException {
		LOGGER.trace("####### LocalCache.getKeys()");
		List<String> keys = getOneJvmCacheImplInstance().getKeys();
		LOGGER.trace("####### keys=" + keys);
		return keys;
	}

	
	public void remove(String key) throws ThrottlingConfigurationException {
		LOGGER.trace(String.format("####### LocalCache.remove(%s)", key));
		getOneJvmCacheImplInstance().remove(key);
	}

	
	private synchronized OneJvmCacheImpl getOneJvmCacheImplInstance() throws ThrottlingConfigurationException {
		return OneJvmCacheImpl.INSTANCE;
	}

	
}
