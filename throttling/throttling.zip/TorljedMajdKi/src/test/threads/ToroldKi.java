package test.threads;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class ToroldKi {

	
	public static void main(String[] args) {
//		ToroldKi toroldKi = new ToroldKi();
		for(int i = 0; i < 5; i++) {
//			final ToroldKi.NotSingleton notSingleton = toroldKi.new NotSingleton(i);
			final int i2 = i;
			new Thread() {
				public void run() {
					System.out.println("***** STARTING " + i2);
					try {
//						Singleton.INSTANCE.waiting(i2);
//						notSingleton.waiting();
						
						OneJvmCacheImpl.INSTANCE.lock("almafa", i2);
						Thread.sleep(2000);
						OneJvmCacheImpl.INSTANCE.unlock("almafa", i2);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("***** ENDING " + i2);
				}
			}.start();
		}
	}
	
	
enum Singleton {
	
	INSTANCE;
	
	public void waiting(int i2) throws InterruptedException {
		synchronized (INSTANCE) {
			for(int i = 0; i < 4; i++) {
				Thread.sleep(500);
				System.out.println(i2 + "--" + i);
			}
		}
	}
}

class NotSingleton {
	private int cnt;
	public NotSingleton(int i){
		cnt=i;
	}
	public void waiting() throws InterruptedException {
		for(int i=0; i<5; i++) {
			Thread.sleep(500);
			System.out.println(cnt + "--" + i);
		}
	}
	
}


public enum OneJvmCacheImpl {

	INSTANCE;
	
	
	private static final String LOCKED_KEY_PREFIX = "LOCKED_KEY__";
	
	private Set<String> lockedkeysSet = Collections.synchronizedSet(new HashSet<String>());
	
	
	public void lock(String key, int thread) throws InterruptedException {
		System.out.println(thread + "  lock - " + key);
		long startTime = System.currentTimeMillis();
		long lockTimeout = getLockTimeout();
		
		synchronized (INSTANCE) {
			waitingForTheLock(key, startTime, lockTimeout);
			
			lockedkeysSet.add(LOCKED_KEY_PREFIX + key);
			System.out.println("   "+ thread + "  acquiring the lock - " + key);
		}
	}


	public void unlock(String key, int thread) {
		System.out.println(thread + "  unlock - " + key);
		lockedkeysSet.remove(LOCKED_KEY_PREFIX+key);
	}
	
	
	private void waitingForTheLock(String key, long startTime, long lockTimeout) throws InterruptedException {
		long actualTime;
		while (lockedkeysSet.contains(LOCKED_KEY_PREFIX + key)) {
			Thread.sleep(10);
			
			actualTime = System.currentTimeMillis();
			if (actualTime - startTime > lockTimeout ) {
				throw new RuntimeException("The lock of OneJvmCacheImpl cannot be acquired! Waiting for the lock is more than " + lockTimeout + " ms.");
			}
		}
	}
	
	
	private long getLockTimeout() {
		return 15000;
	}
}


}
