package org.vhorvath.valogato.web.jmesa;

public class JMesaCell600Px extends JMesaCellParent {

	public JMesaCell600Px() {
		super(600);
	}
	
}
