package org.vhorvath.valogato.common.cache;


import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.vhorvath.valogato.common.dao.lowlevel.configuration.general.GeneralConfigurationUtils;
import org.vhorvath.valogato.common.exception.ThrottlingConfigurationException;
import org.vhorvath.valogato.common.utils.ThrottlingUtils;


public enum OneJvmCacheImpl {

	INSTANCE;
	
	
	private static final String LOCKED_KEY_PREFIX = "LOCKED_KEY__";
	
	private Set<String> lockedkeysSet = Collections.synchronizedSet(new HashSet<String>());
	private ConcurrentHashMap<String, Object> values = new ConcurrentHashMap<String, Object>();
	
	
	public void lock(String key) throws ThrottlingConfigurationException {
		long startTime = System.currentTimeMillis();
		long lockTimeout = getLockTimeout();
		
		synchronized (INSTANCE) {
			waitingForTheLock(key, startTime, lockTimeout);
			
			lockedkeysSet.add(LOCKED_KEY_PREFIX + key);
		}
	}


	public void unlock(String key) {
		lockedkeysSet.remove(LOCKED_KEY_PREFIX+key);
	}
	
	
	public <T> T get(String key, Class<T> type) {
		return type.cast(values.get(key));
	}
	
	
	public void put(String key, Object value) {
		values.put(key, value);
	}
	
	
	public void remove(String key) {
		values.remove(key);
	}

	
	public List<String> getKeys() {
		return Collections.list(values.keys());
	}
	

	private void waitingForTheLock(String key, long startTime, long lockTimeout) {
		long actualTime;
		while (lockedkeysSet.contains(LOCKED_KEY_PREFIX + key)) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				throw new RuntimeException("InterruptedException occurred when trying to do a Thread.sleep()", e);
			}
			
			actualTime = System.currentTimeMillis();
			if (actualTime - startTime > lockTimeout ) {
				throw new RuntimeException("The lock of OneJvmCacheImpl cannot be acquired! Waiting for the lock is more than " + lockTimeout + " ms.");
			}
		}
	}
	
	
	private long getLockTimeout() throws ThrottlingConfigurationException {
		String lockTimeoutText = GeneralConfigurationUtils.getCache().getParams().get("lockTimeout");
		if (lockTimeoutText == null) {
			throw new ThrottlingConfigurationException("The param distributedCacheName is not defined for the LocalCache in ConfigurationGeneral.xml! e.g. <cache type=\"LocalCache\"><param name=\"lockTimeout\">15000</param></cache>");
		}
		
		try {
			return ThrottlingUtils.get(lockTimeoutText, Integer.class);
		} catch(ClassCastException e) {
			throw new ThrottlingConfigurationException("The param distributedCacheName must be integer for the LocalCache in ConfigurationGeneral.xml! e.g. <cache type=\"LocalCache\"><param name=\"lockTimeout\">15000</param></cache>");
		}
	}


}
