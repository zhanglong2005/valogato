package org.vhorvath.valogato.web.actions.administration;

import org.vhorvath.valogato.web.actions.ThrottlingActionSupport;

public class MainBackendServiceConfigAction extends ThrottlingActionSupport {

	private static final long serialVersionUID = 32148120860163030L;

	public String execute() {
		return "SUCCESS";
	}
	
}
