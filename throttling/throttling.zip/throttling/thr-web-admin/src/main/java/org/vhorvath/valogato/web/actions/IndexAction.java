package org.vhorvath.valogato.web.actions;

public class IndexAction {

	public String execute() {
		return "SUCCESS";
	}
	
}
