package org.vhorvath.valogato.web.jmesa;

public class JMesaCell300Px extends JMesaCellParent {

	public JMesaCell300Px() {
		super(300);
	}
	
}
