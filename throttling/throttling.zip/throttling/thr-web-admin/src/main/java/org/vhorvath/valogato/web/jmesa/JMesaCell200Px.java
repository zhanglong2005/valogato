package org.vhorvath.valogato.web.jmesa;

public class JMesaCell200Px extends JMesaCellParent {

	public JMesaCell200Px() {
		super(200);
	}
	
}
