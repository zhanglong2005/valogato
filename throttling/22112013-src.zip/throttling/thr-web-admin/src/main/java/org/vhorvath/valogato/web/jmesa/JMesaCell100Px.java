package org.vhorvath.valogato.web.jmesa;

public class JMesaCell100Px extends JMesaCellParent {

	public JMesaCell100Px() {
		super(100);
	}
	
}
