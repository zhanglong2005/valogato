package org.vhorvath.valogato.web.jmesa;

public class JMesaCell500Px extends JMesaCellParent {

	public JMesaCell500Px() {
		super(500);
	}
	
}
